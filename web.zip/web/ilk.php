<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>BARTINEÖPGİRİŞ</title>
    <link rel="stylesheet" href="ilk.css">
  </head>
  <body>
<div class = "container">
  <div class="navbar">
    <div class="BARTINEÖP">
      <img src="download.png" widht="70px" height="70px" >
<a href="#">BARTINEÖP</a>
</div>
<ul>
  <li  ><a href="ilk.php">ANASAYFA</a></li>
  <li><a href="ekran.php">GİRİŞ YAP</a></li>

</ul>

</div>
</div>


<div class="adlar">
 <ul><li><a href="ilk.php"><h3>ETKİNLİKLER</h3></a></li>
 
  <select name="etkinlikler" >

<option>Kültürsel</option>

<option>Sanatsal</option>

<option>Bilimsel</option>

<option>Becerisel</option>



</select>
    <li><a href="duyuru.php"><h3>DUYURULAR</h3></a></li>
    <li><a href="resimm.php"><h3>EKLE</h3></a></li>
  
  </ul>

</div>
     
      <div class="ornek">
<img src="ogretmen-okullari-afis-copy.jpg" width="350px" height="400px" class="sola-kaydir">

<p ><h3>ÖĞRETMEN OKULLARININ KURULUŞUNUN 172.YIL DÖNÜMÜ ETKİNLİĞİ</h3></p>
<p> <h3>YER:KUTLUBEY KAMPÜSÜ MİMAR SİNAN DERSLİĞİ KONFERANS SALONU</h3>
</p>
<p><h3>
ZAMAN:16 MART 2020 PAZARTESİ SAAT 10.00</h3></p></div>
<p> <a href="kayitolma.php"> <input type="submit" value="KAYIT OL"></a></p>
     
    </body>
</html>
