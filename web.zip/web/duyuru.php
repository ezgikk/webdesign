<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title>BARTINEÖPGİRİŞ</title>
    <link rel="stylesheet" href="duyuru.css">
    <script src="https://kit.fontawesome.com/16b25c7560.js" crossorigin="anonymous"></script>
  </head>
  <body>
<div class = "container">
  <div class="navbar">
    <div class="BARTINEÖP">
      <img src="download.png" widht="70px" height="70px" >
<a href="#">BARTINEÖP</a>
</div>
<ul>
  <li  ><a href="ilk.php">ANASAYFA</a></li>
  <li><a href="ekran.php">GİRİŞ YAP</a></li>

</ul>

</div>
</div>

<div class="adlar">
  <ul><li><a href="ilk.php"><h3>ETKİNLİKLER</h3></a></li>

    <li><a href="duyuru.php"><h3>DUYURULAR</h3></a></li>
    <li><a href="resimm.php"><h3>EKLE</h3></a></li>
  
  </ul>

</div>
<div id="duyuru">
<h4>
<p><i><i class="fa-regular fa-angel"></i>ULUSLARASI ÇALIŞMALARA KATILMAK İSTEYENLER YURTDIŞI PROJELERLE</i> </p><p><i>İLGİLENENLER KİŞİSEL GELİŞİMİNE KATKI SAĞLAMAK İSTEYENLER VİZYON KULUBÜ BAŞLIYOR.</i></p><p><i>WHATSAPP İLE KATILIM SAĞLAYABİLİRSİNİZ.</i></p>
<a href="#"><p><i class="fa-brands fa-whatsapp"></i></p></a>
</h4></div>

</body>
</html>